package com.example.docscanner

import android.content.ActivityNotFoundException
import android.content.Intent
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.FileProvider
import androidx.core.os.LocaleListCompat
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import android.os.Bundle
import androidx.activity.compose.setContent
import java.io.File

class MainActivity : AppCompatActivity() {

    private val vm: MainViewModel by viewModels()

    private val scanLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val scan = GmsDocumentScanningResult.fromActivityResultIntent(result.data)
            val pdfUri = scan?.pdf?.uri
            if (pdfUri != null) vm.onScanned(pdfUri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ScannerTheme {
                LibraryScreen(
                    vm = vm,
                    onScan = ::startScan,
                    onOpenPdf = ::openPdf,
                    onSharePdf = ::sharePdf,
                    onToggleLanguage = ::toggleLanguage
                )
            }
        }
    }

    /**
     * Google's scanner UI handles live edge detection, auto-capture, manual crop,
     * perspective correction, rotation, and cleaning filters (shadow/stain removal).
     * It also needs no camera permission from this app.
     */
    private fun startScan() {
        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(100)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_PDF)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()

        GmsDocumentScanning.getClient(options)
            .getStartScanIntent(this)
            .addOnSuccessListener { intentSender ->
                scanLauncher.launch(IntentSenderRequest.Builder(intentSender).build())
            }
            .addOnFailureListener { vm.showMessage(R.string.scan_failed) }
    }

    private fun uriFor(file: File) =
        FileProvider.getUriForFile(this, "$packageName.fileprovider", file)

    private fun openPdf(file: File) {
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uriFor(file), "application/pdf")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.no_pdf_viewer, Toast.LENGTH_SHORT).show()
        }
    }

    private fun sharePdf(file: File) {
        val intent = Intent(Intent.ACTION_SEND)
            .setType("application/pdf")
            .putExtra(Intent.EXTRA_STREAM, uriFor(file))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(intent, null))
    }

    private fun toggleLanguage() {
        val current = AppCompatDelegate.getApplicationLocales().get(0)?.language
            ?: resources.configuration.locales[0].language
        val next = if (current == "ar") "en" else "ar"
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(next))
    }
}
