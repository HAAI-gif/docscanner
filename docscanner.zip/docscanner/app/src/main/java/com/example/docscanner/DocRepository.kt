package com.example.docscanner

import android.content.Context
import android.net.Uri
import java.io.File

data class LibraryItem(val file: File, val isFolder: Boolean, val childCount: Int) {
    val name: String get() = if (isFolder) file.name else file.nameWithoutExtension
    val modified: Long get() = file.lastModified()
}

/**
 * Stores everything inside the app's private storage: filesDir/library.
 * A folder is a real directory, a document is a PDF file.
 */
class DocRepository(context: Context) {
    private val appContext = context.applicationContext
    val root: File = File(appContext.filesDir, "library").apply { mkdirs() }

    private fun File.isLibraryEntry() = isDirectory || extension.equals("pdf", ignoreCase = true)

    private fun File.toItem() = LibraryItem(
        file = this,
        isFolder = isDirectory,
        childCount = if (isDirectory) listFiles().orEmpty().count { it.isLibraryEntry() } else 0
    )

    fun list(dir: File): List<LibraryItem> {
        val entries = dir.listFiles().orEmpty().filter { it.isLibraryEntry() }
        val folders = entries.filter { it.isDirectory }.sortedBy { it.name.lowercase() }
        val docs = entries.filter { !it.isDirectory }.sortedByDescending { it.lastModified() }
        return (folders + docs).map { it.toItem() }
    }

    fun search(dir: File, query: String): List<LibraryItem> {
        val q = query.trim()
        return dir.walkTopDown()
            .filter { it != dir && it.isLibraryEntry() && it.nameWithoutExtension.contains(q, ignoreCase = true) }
            .map { it.toItem() }
            .toList()
    }

    fun allFolders(): List<File> = root.walkTopDown().filter { it.isDirectory }.toList()

    fun createFolder(parent: File, name: String): Boolean =
        uniqueFile(parent, clean(name), "").mkdir()

    fun savePdf(source: Uri, dir: File, name: String): File {
        val target = uniqueFile(dir, clean(name), ".pdf")
        val input = appContext.contentResolver.openInputStream(source)
            ?: throw IllegalStateException("Cannot read scan result")
        input.use { src -> target.outputStream().use { out -> src.copyTo(out) } }
        return target
    }

    fun rename(item: LibraryItem, newName: String): Boolean {
        val ext = if (item.isFolder) "" else ".pdf"
        val target = File(item.file.parentFile, clean(newName) + ext)
        if (target == item.file) return true
        if (target.exists()) return false
        return item.file.renameTo(target)
    }

    fun move(item: LibraryItem, targetDir: File): Boolean {
        val into = targetDir.canonicalPath + File.separator
        if (item.isFolder && into.startsWith(item.file.canonicalPath + File.separator)) return false
        val ext = if (item.isFolder) "" else ".pdf"
        val base = if (item.isFolder) item.file.name else item.file.nameWithoutExtension
        return item.file.renameTo(uniqueFile(targetDir, base, ext))
    }

    fun delete(item: LibraryItem): Boolean = item.file.deleteRecursively()

    private fun uniqueFile(parent: File, base: String, ext: String): File {
        var candidate = File(parent, base + ext)
        var i = 2
        while (candidate.exists()) {
            candidate = File(parent, "$base ($i)$ext")
            i++
        }
        return candidate
    }

    private fun clean(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|\\r\\n]"), " ")
            .trim()
            .trim('.')
            .take(100)
            .ifBlank { "Untitled" }
}
