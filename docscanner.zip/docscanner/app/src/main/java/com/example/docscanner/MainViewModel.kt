package com.example.docscanner

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = DocRepository(app)

    val rootDir: File get() = repo.root

    var currentDir by mutableStateOf(repo.root)
        private set
    var items by mutableStateOf<List<LibraryItem>>(emptyList())
        private set
    var query by mutableStateOf("")
        private set
    var pendingScan by mutableStateOf<Uri?>(null)
        private set
    var message by mutableStateOf<Int?>(null)
        private set

    val isRoot: Boolean get() = currentDir == repo.root

    init {
        refresh()
    }

    fun refresh() {
        items = if (query.isBlank()) repo.list(currentDir) else repo.search(currentDir, query)
    }

    fun open(dir: File) {
        currentDir = dir
        query = ""
        refresh()
    }

    fun goUp() {
        if (!isRoot) open(currentDir.parentFile ?: repo.root)
    }

    fun setQuery(value: String) {
        query = value
        refresh()
    }

    fun clearMessage() {
        message = null
    }

    fun showMessage(resId: Int) {
        message = resId
    }

    // ---- scanning ----

    fun onScanned(uri: Uri) {
        pendingScan = uri
    }

    fun cancelScan() {
        pendingScan = null
    }

    fun saveScan(name: String) {
        val uri = pendingScan ?: return
        pendingScan = null
        val dir = currentDir
        io { repo.savePdf(uri, dir, name); true }
    }

    // ---- folders and files ----

    fun createFolder(name: String) {
        val dir = currentDir
        io(R.string.name_exists) { repo.createFolder(dir, name) }
    }

    fun rename(item: LibraryItem, name: String) =
        io(R.string.name_exists) { repo.rename(item, name) }

    fun move(item: LibraryItem, target: File) =
        io { repo.move(item, target) }

    fun delete(item: LibraryItem) =
        io { repo.delete(item) }

    fun moveTargets(item: LibraryItem): List<File> = repo.allFolders().filter { dir ->
        val insideItself = item.isFolder &&
            (dir.path + File.separator).startsWith(item.file.path + File.separator)
        dir != item.file.parentFile && !insideItself
    }

    private fun io(failure: Int = R.string.error_generic, block: () -> Boolean) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching(block).getOrDefault(false) }
            if (!ok) message = failure
            refresh()
        }
    }
}
