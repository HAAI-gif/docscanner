package com.example.docscanner

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import java.io.File
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private sealed interface DialogState {
    data object NewFolder : DialogState
    data class Rename(val item: LibraryItem) : DialogState
    data class Move(val item: LibraryItem) : DialogState
    data class Delete(val item: LibraryItem) : DialogState
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    vm: MainViewModel,
    onScan: () -> Unit,
    onOpenPdf: (File) -> Unit,
    onSharePdf: (File) -> Unit,
    onToggleLanguage: () -> Unit
) {
    var dialog by remember { mutableStateOf<DialogState?>(null) }
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current

    BackHandler(enabled = !vm.isRoot) { vm.goUp() }

    LaunchedEffect(vm.message) {
        vm.message?.let {
            snackbar.showSnackbar(context.getString(it))
            vm.clearMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (vm.isRoot) stringResource(R.string.all_files) else vm.currentDir.name,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    if (!vm.isRoot) {
                        IconButton(onClick = { vm.goUp() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back))
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { dialog = DialogState.NewFolder }) {
                        Icon(Icons.Default.CreateNewFolder, stringResource(R.string.new_folder))
                    }
                    IconButton(onClick = onToggleLanguage) {
                        Icon(Icons.Default.Language, stringResource(R.string.language))
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onScan,
                icon = { Icon(Icons.Default.DocumentScanner, contentDescription = null) },
                text = { Text(stringResource(R.string.scan)) }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            OutlinedTextField(
                value = vm.query,
                onValueChange = { vm.setQuery(it) },
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                placeholder = { Text(stringResource(R.string.search)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )
            if (vm.items.isEmpty()) {
                EmptyState()
            } else {
                LazyColumn(contentPadding = PaddingValues(bottom = 96.dp)) {
                    items(vm.items, key = { it.file.path }) { item ->
                        ItemRow(
                            item = item,
                            onClick = {
                                if (item.isFolder) vm.open(item.file) else onOpenPdf(item.file)
                            },
                            onShare = { onSharePdf(item.file) },
                            onAction = { dialog = it }
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }

    // Name the freshly scanned document before saving it
    if (vm.pendingScan != null) {
        val prefix = stringResource(R.string.scan_prefix)
        val defaultName = remember {
            prefix + " " + SimpleDateFormat("yyyy-MM-dd HH-mm", Locale.US).format(Date())
        }
        NameDialog(
            title = stringResource(R.string.document_name),
            initial = defaultName,
            onConfirm = { vm.saveScan(it) },
            onDismiss = { vm.cancelScan() },
            dismissOnClickOutside = false
        )
    }

    when (val d = dialog) {
        null -> Unit
        DialogState.NewFolder -> NameDialog(
            title = stringResource(R.string.folder_name),
            initial = "",
            onConfirm = { vm.createFolder(it); dialog = null },
            onDismiss = { dialog = null }
        )
        is DialogState.Rename -> NameDialog(
            title = stringResource(R.string.rename),
            initial = d.item.name,
            onConfirm = { vm.rename(d.item, it); dialog = null },
            onDismiss = { dialog = null }
        )
        is DialogState.Move -> MoveDialog(
            rootDir = vm.rootDir,
            targets = remember(d.item) { vm.moveTargets(d.item) },
            onPick = { vm.move(d.item, it); dialog = null },
            onDismiss = { dialog = null }
        )
        is DialogState.Delete -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text(stringResource(R.string.delete_title)) },
            text = { Text(stringResource(R.string.delete_message, d.item.name)) },
            confirmButton = {
                TextButton(onClick = { vm.delete(d.item); dialog = null }) {
                    Text(stringResource(R.string.delete))
                }
            },
            dismissButton = {
                TextButton(onClick = { dialog = null }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }
}

@Composable
private fun ItemRow(
    item: LibraryItem,
    onClick: () -> Unit,
    onShare: () -> Unit,
    onAction: (DialogState) -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    val dateFormat = remember { DateFormat.getDateInstance(DateFormat.MEDIUM) }

    ListItem(
        modifier = Modifier.clickable(onClick = onClick),
        leadingContent = {
            if (item.isFolder) {
                Icon(
                    Icons.Default.Folder,
                    contentDescription = null,
                    modifier = Modifier.size(48.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
            } else {
                PdfThumb(item.file, Modifier.size(width = 48.dp, height = 64.dp))
            }
        },
        headlineContent = { Text(item.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        supportingContent = {
            Text(
                if (item.isFolder) stringResource(R.string.items_count, item.childCount)
                else dateFormat.format(Date(item.modified))
            )
        },
        trailingContent = {
            Box {
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = null)
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.rename)) },
                        leadingIcon = { Icon(Icons.Default.Edit, null) },
                        onClick = { menuOpen = false; onAction(DialogState.Rename(item)) }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.move)) },
                        leadingIcon = { Icon(Icons.Default.DriveFileMove, null) },
                        onClick = { menuOpen = false; onAction(DialogState.Move(item)) }
                    )
                    if (!item.isFolder) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.share)) },
                            leadingIcon = { Icon(Icons.Default.Share, null) },
                            onClick = { menuOpen = false; onShare() }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.delete)) },
                        leadingIcon = { Icon(Icons.Default.Delete, null) },
                        onClick = { menuOpen = false; onAction(DialogState.Delete(item)) }
                    )
                }
            }
        }
    )
}

@Composable
private fun EmptyState() {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.height(48.dp))
        Icon(
            Icons.Default.DocumentScanner,
            contentDescription = null,
            modifier = Modifier.size(72.dp),
            tint = MaterialTheme.colorScheme.outline
        )
        Text(
            stringResource(R.string.empty_title),
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(top = 16.dp)
        )
        Text(
            stringResource(R.string.empty_hint),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
private fun NameDialog(
    title: String,
    initial: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
    dismissOnClickOutside: Boolean = true
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(dismissOnClickOutside = dismissOnClickOutside),
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) {
                Text(stringResource(R.string.save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        }
    )
}

@Composable
private fun MoveDialog(
    rootDir: File,
    targets: List<File>,
    onPick: (File) -> Unit,
    onDismiss: () -> Unit
) {
    val rootLabel = stringResource(R.string.all_files)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.move_to)) },
        text = {
            if (targets.isEmpty()) {
                Text(stringResource(R.string.no_folders))
            } else {
                LazyColumn {
                    items(targets, key = { it.path }) { folder ->
                        val label = if (folder == rootDir) rootLabel else folder.relativeTo(rootDir).path
                        ListItem(
                            modifier = Modifier.clickable { onPick(folder) },
                            leadingContent = { Icon(Icons.Default.Folder, contentDescription = null) },
                            headlineContent = { Text(label, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                        )
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        }
    )
}
